import csv
import json
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt


ROOT = Path("outputs/experiments")
OUTPUT = Path("outputs/analysis")
SEEDS = [42, 43, 44]

GROUP_VALUES = {
    "A": list(range(200, 2001, 200)),
    "B": list(range(1, 11)),
    "C": list(range(1, 5)),
}

X_LABELS = {
    "A": "So mau train",
    "B": "So neuron tang an",
    "C": "So tang an",
}

METRICS = [
    "train_mse",
    "val_mse",
    "test_mse",
    "test_mae",
    "test_rmse",
    "training_seconds",
    "best_epoch",
]

# Đọc và kiểm tra đủ kết quả trước khi xuất bảng.
all_results = {}

for group, values in GROUP_VALUES.items():
    rows = []

    for value in values:
        runs = []

        for seed in SEEDS:
            path = (
                ROOT / group
                / f"value_{value}"
                / f"seed_{seed}"
                / "metrics.json"
            )

            if not path.exists():
                raise FileNotFoundError(
                    f"Chưa có kết quả: {path}"
                )

            metrics = json.loads(path.read_text(encoding="utf-8"))

            for metric in METRICS:
                if metric not in metrics:
                    raise ValueError(
                        f"{path} thiếu {metric}. "
                        "Nếu thiếu test metrics, hãy chạy --evaluate-test."
                    )

                if not np.isfinite(metrics[metric]):
                    raise ValueError(
                        f"{path}: {metric} không hữu hạn."
                    )

            runs.append(metrics)

        row = {
            "group": group,
            "value": value,
            "n_seeds": len(runs),
        }

        for metric in METRICS:
            numbers = np.array(
                [run[metric] for run in runs],
                dtype=float
            )

            row[f"{metric}_mean"] = numbers.mean()
            row[f"{metric}_std"] = numbers.std(ddof=1)

        rows.append(row)

    all_results[group] = rows

OUTPUT.mkdir(parents=True, exist_ok=True)

for group, rows in all_results.items():
    path = OUTPUT / f"{group}_summary.csv"

    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=list(rows[0])
        )
        writer.writeheader()
        writer.writerows(rows)

    print(f"\nNhom {group}:")
    for row in rows:
        print(
            f"  value={row['value']:4d} | "
            f"test MSE = {row['test_mse_mean']:.8f} "
            f"+/- {row['test_mse_std']:.8f}"
        )

    # Lựa chọn theo validation trung bình, không theo test.
    selected = min(rows, key=lambda row: row["val_mse_mean"])
    print(
        "  Cau hinh co validation MSE trung binh thap nhat:",
        selected["value"]
    )

for group, rows in all_results.items():
    x = [row["value"] for row in rows]

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    # Biểu đồ MSE của train, validation và test.
    for metric, label in [
        ("train_mse", "Train"),
        ("val_mse", "Validation"),
        ("test_mse", "Test"),
    ]:
        means = [row[f"{metric}_mean"] for row in rows]
        stds = [row[f"{metric}_std"] for row in rows]

        axes[0].errorbar(
            x, means, yerr=stds,
            marker="o", capsize=3,
            label=label
        )

    axes[0].set_xlabel(X_LABELS[group])
    axes[0].set_ylabel("MSE")
    axes[0].set_title(f"Nhom {group}: MSE, mean +/- SD")
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    # Biểu đồ RMSE trên test.
    axes[1].errorbar(
        x,
        [row["test_rmse_mean"] for row in rows],
        yerr=[row["test_rmse_std"] for row in rows],
        marker="o",
        capsize=3,
        color="tab:green"
    )

    axes[1].set_xlabel(X_LABELS[group])
    axes[1].set_ylabel("Test RMSE")
    axes[1].set_title(f"Nhom {group}: test RMSE, mean +/- SD")
    axes[1].grid(True, alpha=0.3)

    for ax in axes:
        ax.set_xticks(x)

    fig.tight_layout()
    fig.savefig(OUTPUT / f"{group}_errors.png", dpi=180)
    plt.close(fig)


rows = all_results["C"]

plt.figure(figsize=(8, 5))
plt.errorbar(
    [row["value"] for row in rows],
    [row["training_seconds_mean"] for row in rows],
    yerr=[row["training_seconds_std"] for row in rows],
    marker="o",
    capsize=4
)
plt.xticks([1, 2, 3, 4])
plt.xlabel("So tang an")
plt.ylabel("Thoi gian train (giay)")
plt.title("Nhom C: thoi gian train, mean +/- SD")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(OUTPUT / "C_training_time.png", dpi=180)
plt.close()

# Minh họa hội tụ bằng seed 42 cho tất cả độ sâu.
# Không chọn seed riêng theo kết quả tốt nhất.
fig, axes = plt.subplots(1, 2, figsize=(13, 5))

for depth in GROUP_VALUES["C"]:
    path = (
        ROOT / "C"
        / f"value_{depth}"
        / "seed_42"
        / "training_log.csv"
    )

    with path.open(encoding="utf-8") as file:
        history = list(csv.DictReader(file))

    epochs = [int(row["epoch"]) for row in history]
    train_mse = [float(row["train_mse"]) for row in history]
    val_mse = [float(row["val_mse"]) for row in history]

    axes[0].plot(epochs, train_mse, label=f"{depth} layers")
    axes[1].plot(epochs, val_mse, label=f"{depth} layers")

for ax, title in zip(axes, ["Train MSE", "Validation MSE"]):
    ax.set_xlabel("Epoch")
    ax.set_ylabel("MSE")
    ax.set_title(f"{title} - seed 42")
    ax.legend()
    ax.grid(True, alpha=0.3)

fig.tight_layout()
fig.savefig(OUTPUT / "C_convergence_seed42.png", dpi=180)
plt.close(fig)

print(f"\nDa luu bang va bieu do tai: {OUTPUT}")