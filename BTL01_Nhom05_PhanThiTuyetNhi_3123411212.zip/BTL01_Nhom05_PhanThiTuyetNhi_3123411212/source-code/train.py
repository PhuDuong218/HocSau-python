import csv
import time
from pathlib import Path

import matplotlib.pyplot as plt
import torch
from torch import nn

from dataset import create_loaders
from model import MLP


# Cấu hình baseline
SEED = 42
BATCH_SIZE = 32
HIDDEN_SIZES = [10]
LEARNING_RATE = 0.001
MAX_EPOCHS = 1000
PATIENCE = 100

# Seed cho khởi tạo trọng số và các phép ngẫu nhiên của PyTorch.
torch.manual_seed(SEED)

# GPU là tùy chọn; chương trình vẫn chạy được trên CPU.
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Thiết bị:", device)

train_loader, val_loader, test_loader = create_loaders(
    data_dir="data",
    batch_size=BATCH_SIZE,
    seed=SEED
)

model = MLP(hidden_sizes=HIDDEN_SIZES).to(device)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)

# Nơi lưu kết quả của lần chạy baseline.
output_dir = Path("outputs") / "baseline"
output_dir.mkdir(parents=True, exist_ok=True)

checkpoint_path = output_dir / "best_model.pt" 

def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()

    total_squared_error = 0.0
    total_samples = 0

    for X_batch, y_batch in loader:
        X_batch = X_batch.to(device)  # (B, 2)
        y_batch = y_batch.to(device)  # (B, 1)

        # Forward: (B, 2) -> (B, 1)
        predictions = model(X_batch)

        # Phòng lỗi broadcasting giữa (B, 1) và (B,).
        assert predictions.shape == y_batch.shape

        loss = criterion(predictions, y_batch)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        batch_size = X_batch.size(0)

        # MSELoss mặc định là trung bình trong batch.
        total_squared_error += loss.item() * batch_size
        total_samples += batch_size

    return total_squared_error / total_samples


def evaluate_mse(model, loader, criterion, device):
    model.eval()

    total_squared_error = 0.0
    total_samples = 0

    # Validation không cần tính gradient.
    with torch.no_grad():
        for X_batch, y_batch in loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)

            predictions = model(X_batch)
            assert predictions.shape == y_batch.shape

            loss = criterion(predictions, y_batch)

            batch_size = X_batch.size(0)
            total_squared_error += loss.item() * batch_size
            total_samples += batch_size

    return total_squared_error / total_samples


best_val_mse = float("inf")
best_epoch = 0
epochs_without_improvement = 0
history = []

start_time = time.perf_counter()

for epoch in range(1, MAX_EPOCHS + 1):
    train_mse = train_one_epoch(
        model, train_loader, criterion, optimizer, device
    )

    val_mse = evaluate_mse(
        model, val_loader, criterion, device
    )

    history.append({
        "epoch": epoch,
        "train_mse": train_mse,
        "val_mse": val_mse,
    })

    if val_mse < best_val_mse:
        best_val_mse = val_mse
        best_epoch = epoch
        epochs_without_improvement = 0

        # Lưu cả kiến trúc và phép chuẩn hóa để tái sử dụng.
        torch.save({
            "model_state_dict": model.state_dict(),
            "hidden_sizes": HIDDEN_SIZES,
            "input_scale": [2.0, 4.0],
            "seed": SEED,
            "epoch": epoch,
            "val_mse": val_mse,
        }, checkpoint_path)
    else:
        epochs_without_improvement += 1

    if epoch == 1 or epoch % 50 == 0:
        print(
            f"Epoch {epoch:4d} | "
            f"train MSE: {train_mse:.8f} | "
            f"val MSE: {val_mse:.8f}"
        )

    if epochs_without_improvement >= PATIENCE:
        print(f"Dừng sớm tại epoch {epoch}.")
        break

training_seconds = time.perf_counter() - start_time

print(f"\nEpoch tốt nhất: {best_epoch}")
print(f"Validation MSE tốt nhất: {best_val_mse:.8f}")
print(f"Thời gian train: {training_seconds:.2f} giây")
print(f"Checkpoint: {checkpoint_path}")


log_path = output_dir / "training_log.csv"

with log_path.open("w", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(
        file,
        fieldnames=["epoch", "train_mse", "val_mse"]
    )
    writer.writeheader()
    writer.writerows(history)

epochs = [row["epoch"] for row in history]
train_losses = [row["train_mse"] for row in history]
val_losses = [row["val_mse"] for row in history]

plt.figure(figsize=(9, 5))
plt.plot(epochs, train_losses, label="Train MSE")
plt.plot(epochs, val_losses, label="Validation MSE")
plt.axvline(best_epoch, color="gray", linestyle="--", label="Best epoch")
plt.xlabel("Epoch")
plt.ylabel("MSE")
plt.title("Training va validation MSE")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig(output_dir / "loss_curve.png", dpi=150)
plt.close()

print(f"Đã lưu log: {log_path}")

# Khôi phục mô hình có validation MSE tốt nhất.
checkpoint = torch.load(checkpoint_path, map_location=device)
best_model = MLP(hidden_sizes=checkpoint["hidden_sizes"]).to(device)
best_model.load_state_dict(checkpoint["model_state_dict"])
best_model.eval()

total_squared_error = 0.0
total_absolute_error = 0.0
total_samples = 0

all_predictions = []
all_targets = []
all_inputs = []

with torch.no_grad():
    for X_batch, y_batch in test_loader:
        X_batch = X_batch.to(device)
        y_batch = y_batch.to(device)

        predictions = best_model(X_batch)
        errors = predictions - y_batch

        total_squared_error += torch.sum(errors ** 2).item()
        total_absolute_error += torch.sum(torch.abs(errors)).item()
        total_samples += y_batch.size(0)

        all_inputs.append(X_batch.cpu())
        all_targets.append(y_batch.cpu())
        all_predictions.append(predictions.cpu())

test_mse = total_squared_error / total_samples
test_mae = total_absolute_error / total_samples
test_rmse = test_mse ** 0.5

print(f"\nTest MSE:  {test_mse:.8f}")
print(f"Test MAE:  {test_mae:.8f}")
print(f"Test RMSE: {test_rmse:.8f}")

# DataLoader đã chuẩn hóa X; nhân lại để lưu tọa độ gốc.
X_test_original = torch.cat(all_inputs).numpy() * checkpoint["input_scale"]
y_test = torch.cat(all_targets).numpy()
y_pred = torch.cat(all_predictions).numpy()

prediction_path = output_dir / "test_predictions.csv"

with prediction_path.open("w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["x1", "x2", "y_true", "y_pred"])

    for x, true_value, predicted_value in zip(
        X_test_original, y_test, y_pred
    ):
        writer.writerow([
            float(x[0]),
            float(x[1]),
            float(true_value[0]),
            float(predicted_value[0]),
        ])

# Biểu đồ giá trị thật so với dự đoán.
plt.figure(figsize=(6, 6))
plt.scatter(y_test[:, 0], y_pred[:, 0], alpha=0.7, s=20)

lower = min(float(y_test.min()), float(y_pred.min()))
upper = max(float(y_test.max()), float(y_pred.max()))
plt.plot([lower, upper], [lower, upper], "r--", label="Du doan hoan hao")

plt.xlabel("y thật")
plt.ylabel("y dự đoán")
plt.title("So sánh trên tập test")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig(output_dir / "test_predictions.png", dpi=150)
plt.close()

print(f"Đã lưu dự đoán: {prediction_path}")