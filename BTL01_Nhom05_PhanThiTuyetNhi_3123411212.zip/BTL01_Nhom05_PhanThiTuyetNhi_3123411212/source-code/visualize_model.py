import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch

from model import MLP


# Đọc bảng tổng hợp và chọn cấu hình theo validation MSE trung bình.
analysis_dir = Path("outputs/analysis")
candidates = []

for group in ["A", "B", "C"]:
    summary_path = analysis_dir / f"{group}_summary.csv"

    with summary_path.open(encoding="utf-8", newline="") as file:
        for row in csv.DictReader(file):
            candidates.append({
                "group": group,
                "value": int(row["value"]),
                "val_mse_mean": float(row["val_mse_mean"]),
            })

selected = min(candidates, key=lambda item: item["val_mse_mean"])

group = selected["group"]
value = selected["value"]

print("Cấu hình chọn theo validation:", selected)
print("Checkpoint minh họa: seed 42")

checkpoint_path = (
    Path("outputs/experiments")
    / group
    / f"value_{value}"
    / "seed_42"
    / "best_model.pt"
)

# Chạy inference trên CPU để dễ tái lập và không cần GPU.
device = torch.device("cpu")
checkpoint = torch.load(checkpoint_path, map_location=device)

model = MLP(checkpoint["hidden_sizes"]).to(device)
model.load_state_dict(checkpoint["model_state_dict"])
model.eval()

input_scale = np.array(checkpoint["input_scale"], dtype=np.float32)

output_dir = Path("outputs/selected_model")
output_dir.mkdir(parents=True, exist_ok=True)

print("Checkpoint:", checkpoint_path)
print("Kiến trúc:", checkpoint["hidden_sizes"])
print("Epoch của checkpoint:", checkpoint["epoch"])
print("Validation MSE của seed 42:", checkpoint["val_mse"])

# Lưới trên miền dữ liệu gốc.
x1 = np.linspace(-2.0, 2.0, 80)
x2 = np.linspace(-4.0, 4.0, 80)
grid_x1, grid_x2 = np.meshgrid(x1, x2)

# points có shape (80 * 80, 2).
points = np.column_stack(
    [grid_x1.ravel(), grid_x2.ravel()]
)

# Tính Gaussian thật trên lưới.
mu = np.array([0.0, 0.0])
C = np.array([
    [0.3, -0.5],
    [-0.5, 2.0]
])

delta = points - mu
C_inv = np.linalg.inv(C)

# Mỗi hàng nhận một giá trị của biểu thức delta.T @ C_inv @ delta.
quadratic = np.sum((delta @ C_inv) * delta, axis=1)
coefficient = 1.0 / (2.0 * np.pi * np.sqrt(np.linalg.det(C)))
true_values = coefficient * np.exp(-0.5 * quadratic)

# Chuẩn hóa giống dataset.py trước khi đưa vào MLP.
normalized_points = points.astype(np.float32) / input_scale
X_tensor = torch.tensor(normalized_points, dtype=torch.float32)

with torch.no_grad():
    predicted_values = model(X_tensor).cpu().numpy().reshape(-1)

true_surface = true_values.reshape(grid_x1.shape)
predicted_surface = predicted_values.reshape(grid_x1.shape)
absolute_error = np.abs(true_surface - predicted_surface)

fig = plt.figure(figsize=(15, 5))

ax1 = fig.add_subplot(131, projection="3d")
ax1.plot_surface(grid_x1, grid_x2, true_surface, cmap="viridis")
ax1.set_title("Gaussian that")
ax1.set_xlabel("x1")
ax1.set_ylabel("x2")
ax1.set_zlabel("y")

ax2 = fig.add_subplot(132, projection="3d")
ax2.plot_surface(grid_x1, grid_x2, predicted_surface, cmap="viridis")
ax2.set_title("MLP du doan")
ax2.set_xlabel("x1")
ax2.set_ylabel("x2")
ax2.set_zlabel("y du doan")

# Cùng thang trục z để việc so sánh hai bề mặt có ý nghĩa.
z_min = min(float(true_surface.min()), float(predicted_surface.min()))
z_max = max(float(true_surface.max()), float(predicted_surface.max()))
ax1.set_zlim(z_min, z_max)
ax2.set_zlim(z_min, z_max)

ax3 = fig.add_subplot(133)
heatmap = ax3.pcolormesh(
    grid_x1, grid_x2, absolute_error,
    shading="auto", cmap="magma"
)
ax3.set_title("Sai so tuyet doi tren luoi")
ax3.set_xlabel("x1")
ax3.set_ylabel("x2")
fig.colorbar(heatmap, ax=ax3, label="|y - y du doan|")

fig.tight_layout()
fig.savefig(output_dir / "surface_comparison.png", dpi=180)
plt.close(fig)

print("Sai số tuyệt đối trung bình trên lưới:", absolute_error.mean())
print("Sai số tuyệt đối lớn nhất trên lưới:", absolute_error.max())


# Đọc CSV gốc để giữ tọa độ và thứ tự mẫu.
test_data = np.loadtxt(
    "data/test.csv",
    delimiter=",",
    skiprows=1,
    ndmin=2
)

X_test_original = test_data[:, :2]
y_true = test_data[:, 2:3]

X_test_normalized = (
    X_test_original.astype(np.float32) / input_scale
)

with torch.no_grad():
    y_pred = model(
        torch.tensor(X_test_normalized, dtype=torch.float32)
    ).cpu().numpy()

assert y_pred.shape == y_true.shape

errors = y_pred - y_true
mse = np.mean(errors ** 2)
mae = np.mean(np.abs(errors))
rmse = np.sqrt(mse)

prediction_path = output_dir / "test_predictions.csv"

with prediction_path.open(
    "w", newline="", encoding="utf-8"
) as file:
    writer = csv.writer(file)
    writer.writerow(["x1", "x2", "y_true", "y_pred"])

    for x, true, pred in zip(X_test_original, y_true, y_pred):
        writer.writerow([
            float(x[0]),
            float(x[1]),
            float(true[0]),
            float(pred[0])
        ])

print(f"Test MSE:  {mse:.8f}")
print(f"Test MAE:  {mae:.8f}")
print(f"Test RMSE: {rmse:.8f}")
print("Đã lưu:", prediction_path)