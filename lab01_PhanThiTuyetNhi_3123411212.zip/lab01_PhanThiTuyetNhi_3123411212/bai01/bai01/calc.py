def cong(a, b):
    return a + b


def tru(a, b):
    return a - b


def nhan(a, b):
    return a * b


def chia(a, b):
    if b == 0:
        return "Không thể chia cho 0"
    return a / b


a = 10
b = 5

print("a =", a)
print("b =", b)
print("Tổng =", cong(a, b))
print("Hiệu =", tru(a, b))
print("Tích =", nhan(a, b))
print("Thương =", chia(a, b))
