import numpy as np

# Vector trung bình: shape (2,)
mu = np.array([0.0, 0.0])

# Ma trận hiệp phương sai: shape (2, 2)
C = np.array([
    [0.3, -0.5],
    [-0.5, 2.0]
])

def gaussian_2d(x):
    """
    Tính mật độ Gaussian tại một điểm x = [x1, x2].

    Input:
        x: mảng có shape (2,)

    Output:
        Một số thực y = f(x1, x2)
    """
    x = np.asarray(x , dtype = float)

    # delta = x - mu, shape (2,)
    delta = x - mu

    # C_inv có shape (2, 2)
    C_inv = np.linalg.inv(C)

    # delta.T @ C_inv @ delta cho ra một số vô hướng
    exponent = -0.5 * (delta.T @ C_inv @ delta)

    # Hệ số chuẩn hóa của Gaussian hai chiều
    coefficient = 1.0 / (2.0 * np.pi * np.sqrt(np.linalg.det(C)))

    return coefficient * np.exp(exponent)

# Kiểm tra tại tâm và hai điểm đối xứng
print("Định thức C:", np.linalg.det(C))
print("f(0, 0):", gaussian_2d([0.0, 0.0]))
print("f(1, 2):", gaussian_2d([1.0, 2.0]))
print("f(-1, -2):", gaussian_2d([-1.0, -2.0]))

def generate_dataset(n_samples, rng):
    """
    Sinh dữ liệu cho bài toán xấp xỉ Gaussian.

    Input:
        n_samples: số mẫu cần sinh
        rng: bộ sinh số ngẫu nhiên NumPy

    Output:
        X: tọa độ các điểm, shape (n_samples, 2)
        y: giá trị Gaussian, shape (n_samples, 1)
    """
    # Mỗi hàng trong X là một điểm [x1, x2].
    X = rng.uniform(
        low=[-2.0, -4.0],
        high=[2.0, 4.0],
        size=(n_samples, 2)
    )

    # Tính nhãn cho từng điểm bằng hàm đã viết.
    y = np.array([gaussian_2d(point) for point in X])

    # Chuyển từ (n_samples,) thành (n_samples, 1).
    y = y.reshape(-1, 1)

    return X, y

# Một seed gốc tạo ra ba luồng ngẫu nhiên riêng.
SEED = 42
seed_train, seed_val, seed_test = np.random.SeedSequence(SEED).spawn(3)

rng_train = np.random.default_rng(seed_train)
rng_val = np.random.default_rng(seed_val)
rng_test = np.random.default_rng(seed_test)

X_train, y_train = generate_dataset(2000, rng_train)
X_val, y_val = generate_dataset(400, rng_val)
X_test, y_test = generate_dataset(100, rng_test)

print("\nKích thước các tập:")
print("Train:", X_train.shape, y_train.shape)
print("Validation:", X_val.shape, y_val.shape)
print("Test:", X_test.shape, y_test.shape)

print("\nBa mẫu train đầu tiên:")
for i in range(3):
    print(f"X = {X_train[i]}, y = {y_train[i, 0]:.6f}")


def inspect_dataset(name, X, y):
    print(f"\n--- {name} ---")
    print("Shape X:", X.shape)
    print("Shape y:", y.shape)

    print(
        "x1:",
        "min =", X[:, 0].min(),
        "max =", X[:, 0].max(),
        "mean =", X[:, 0].mean()
    )
    print(
        "x2:",
        "min =", X[:, 1].min(),
        "max =", X[:, 1].max(),
        "mean =", X[:, 1].mean()
    )
    print(
        "y:",
        "min =", y.min(),
        "max =", y.max(),
        "mean =", y.mean()
    )

    print("Tỷ lệ y < 0.01:", np.mean(y < 0.01))

    # Kiểm tra các điều kiện cần có của dữ liệu.
    assert X.shape == (len(X), 2)
    assert y.shape == (len(X), 1)
    assert np.isfinite(X).all()
    assert np.isfinite(y).all()
    assert np.all((X[:, 0] >= -2) & (X[:, 0] <= 2))
    assert np.all((X[:, 1] >= -4) & (X[:, 1] <= 4))
    assert np.all(y >= 0)


inspect_dataset("TRAIN", X_train, y_train)
inspect_dataset("VALIDATION", X_val, y_val)
inspect_dataset("TEST", X_test, y_test)

# Lưu dữ liệu ra CSV 
from pathlib import Path

# Tạo thư mục data nếu chưa có.
data_dir = Path("data")
data_dir.mkdir(exist_ok=True)


def save_dataset(file_path, X, y):
    # Ghép X: (N, 2) và y: (N, 1) thành bảng: (N, 3).
    data = np.column_stack((X, y))

    np.savetxt(
        file_path,
        data,
        delimiter=",",
        header="x1,x2,y",
        comments="",
        fmt="%.17g"
    )

    print(f"Đã lưu: {file_path}")


save_dataset(data_dir / "train.csv", X_train, y_train)
save_dataset(data_dir / "validation.csv", X_val, y_val)
save_dataset(data_dir / "test.csv", X_test, y_test)

# Vẽ scatter 3D và phân bố nhãn
import matplotlib.pyplot as plt

# Tạo nơi lưu hình.
figure_dir = Path("figures")
figure_dir.mkdir(exist_ok=True)

# Scatter 3D của tập train.
fig = plt.figure(figsize=(9, 6))
ax = fig.add_subplot(111, projection="3d")

ax.scatter(
    X_train[:, 0],
    X_train[:, 1],
    y_train[:, 0],
    s=6,
    alpha=0.5
)

ax.set_xlabel("x1")
ax.set_ylabel("x2")
ax.set_zlabel("y = f(x1, x2)")
ax.set_title("Du lieu train: Gaussian 2D")

plt.tight_layout()
plt.savefig(figure_dir / "train_scatter_3d.png", dpi=150)
plt.close()

# Histogram nhãn của ba tập.
plt.figure(figsize=(9, 5))

plt.hist(y_train[:, 0], bins=30, density=True, alpha=0.5, label="Train")
plt.hist(y_val[:, 0], bins=30, density=True, alpha=0.5, label="Validation")
plt.hist(y_test[:, 0], bins=30, density=True, alpha=0.5, label="Test")

plt.xlabel("Gia tri y")
plt.ylabel("Mat do")
plt.title("Phan bo nhan Gaussian")
plt.legend()
plt.tight_layout()
plt.savefig(figure_dir / "label_distribution.png", dpi=150)
plt.close()

print("Đã lưu biểu đồ vào thư mục figures.")

# Vẽ bề mặt hàm gaussian thật
# Tạo lưới tọa độ trên toàn miền của đề.
x1_grid = np.linspace(-2.0, 2.0, 80)
x2_grid = np.linspace(-4.0, 4.0, 80)

grid_x1, grid_x2 = np.meshgrid(x1_grid, x2_grid)

# Mỗi hàng trong grid_points là một cặp [x1, x2].
grid_points = np.column_stack((grid_x1.ravel(), grid_x2.ravel()))

# Tính Gaussian tại mỗi điểm, rồi đưa về shape của lưới.
grid_y = np.array([gaussian_2d(point) for point in grid_points])
grid_y = grid_y.reshape(grid_x1.shape)

fig = plt.figure(figsize=(9, 6))
ax = fig.add_subplot(111, projection="3d")

ax.plot_surface(grid_x1, grid_x2, grid_y, cmap="viridis")

ax.set_xlabel("x1")
ax.set_ylabel("x2")
ax.set_zlabel("f(x1, x2)")
ax.set_title("Be mat Gaussian that")

plt.tight_layout()
plt.savefig(figure_dir / "gaussian_surface.png", dpi=150)
plt.close()

print("Đã lưu bề mặt Gaussian.")