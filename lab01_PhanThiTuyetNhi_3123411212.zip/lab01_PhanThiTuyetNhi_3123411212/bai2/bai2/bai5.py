n = int(input("Moi ban nhap so nguyen n: "))
a_n = range(1, n + 1) # sinh khoản các số từ 1 đến n

s = 0
for i in a_n:
    if i % 2 == 0:
        s = s + i

print(f'Tong cac so chan tu 1 den {n} la {s}.')