t = int(input('Nhap vao tong so giay: '))

hh = t // (60*60)
mm = (t % (60 * 60)) // 60
ss = t % 60

print(f'{t} giay co dang {hh}:{mm}:{ss}')