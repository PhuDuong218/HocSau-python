import torch
from torch import nn


class MLP(nn.Module):
    def __init__(self, hidden_sizes):
        """
        hidden_sizes: danh sách số neuron của từng tầng ẩn.

        Ví dụ:
            [10]     -> 1 tầng ẩn, 10 neuron
            [10, 10] -> 2 tầng ẩn, mỗi tầng 10 neuron
        """
        super().__init__()

        if not hidden_sizes or any(size <= 0 for size in hidden_sizes):
            raise ValueError("Cần ít nhất một tầng ẩn có số neuron > 0.")

        layers = []
        input_size = 2

        for hidden_size in hidden_sizes:
            layers.append(nn.Linear(input_size, hidden_size))
            layers.append(nn.Tanh())
            input_size = hidden_size

        # Đầu ra tuyến tính: dự đoán một giá trị liên tục.
        layers.append(nn.Linear(input_size, 1))

        self.network = nn.Sequential(*layers)

    def forward(self, x):
        # Ví dụ hidden_sizes=[10]:
        # x:      (batch_size, 2)
        # hidden: (batch_size, 10)
        # output: (batch_size, 1)
        return self.network(x)


if __name__ == "__main__":
    model = MLP(hidden_sizes=[10])

    # Dữ liệu giả chỉ để kiểm tra shape.
    X_example = torch.randn(32, 2)
    predictions = model(X_example)

    print(model)
    print("Input shape:", X_example.shape)
    print("Output shape:", predictions.shape)
    print("Số tham số:", sum(p.numel() for p in model.parameters()))