n = int(input("Moi ban nhap so nguyen n: "))

if n == 1:
    lant = True
else:
    i = 2
    lant = True
    while i*i <= n:
        if n % i == 0: 
            lant = False
            print(i)
            break
        i = i + 1

if lant == True:
    print(f'{n} la so nguyen to.')
else:
    print(f'{n} khong la so nguyen to.')