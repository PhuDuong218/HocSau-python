def NhapDuLieu():

    is_valid = False
    while is_valid == False:
        try:
            line = input("Moi ban nhap he so a, b, c: ")
            a_snum = line.split(" ")
            a, b, c = int(a_snum[0]), int(a_snum[1]), int(a_snum[2])
            is_valid = True
        except:
            print("Du lieu nhap vao khong hop le. Vui long nhap lai.")

    return a, b, c


def GiaiPhuongTrinhBac2(a, b, c):

    import math

    flag = None
    x = ()

    if a == 0:  # bx + c = 0

        if b == 0:  # c = 0

            if c == 0:  # 0 = 0: VSN
                flag = -1

            else:  # c != 0: VN
                flag = 0

        else:
            flag = 1
            x1 = -c / b
            x = x + (x1,)

    else:
        delta = b * b - 4 * a * c

        if delta < 0:
            flag = 0

        elif delta == 0:
            flag = 1
            x = (-b / (2 * a),)

        else:
            flag = 2
            x1 = (-b - math.sqrt(delta)) / (2 * a)
            x2 = (-b + math.sqrt(delta)) / (2 * a)
            x = x + (x1, x2)

    return flag, x


# Nhap du lieu
a, b, c = NhapDuLieu()

# Giai phuong trinh
flag, x = GiaiPhuongTrinhBac2(a, b, c)

# Hien thi
s = f'Phuong trinh bac 2 {a}x^2 + {b}x + {c} = 0'

if flag == -1:
    print(f'{s} co vo so nghiem!')

elif flag == 0:
    print(f'{s} vo nghiem!')

elif flag == 1:
    print(f'{s} co 1 nghiem, x = {x[0]}!')

elif flag == 2:
    print(f'{s} co 2 nghiem, x1 = {x[0]}, x2 = {x[1]}!')