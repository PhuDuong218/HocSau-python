import argparse
import csv
import json
from pathlib import Path

import torch
from torch.utils.data import DataLoader, Subset

from dataset import create_loaders
from engine import evaluate, fit
from model import MLP


def get_configs(group):
    if group == "A":
        return [
            (n, n, [10])
            for n in range(200, 2001, 200)
        ]

    if group == "B":
        return [
            (width, 2000, [width])
            for width in range(1, 11)
        ]

    return [
        (depth, 2000, [10] * depth)
        for depth in range(1, 5)
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--group", choices=["A", "B", "C"], required=True)
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 43, 44])
    parser.add_argument("--evaluate-test", action="store_true")
    args = parser.parse_args()

    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )

    root = Path("outputs") / "experiments" / args.group
    root.mkdir(parents=True, exist_ok=True)
    results = []

    for value, train_size, hidden_sizes in get_configs(args.group):
        for seed in args.seeds:
            run_dir = root / f"value_{value}" / f"seed_{seed}"
            config_path = run_dir / "config.json"
            metrics_path = run_dir / "metrics.json"

            _, val_loader, test_loader = create_loaders(
                batch_size=32, seed=seed
            )

            if args.evaluate_test:
                # Chỉ đọc checkpoint đã huấn luyện, không train lại.
                config = json.loads(
                    config_path.read_text(encoding="utf-8")
                )
                metrics = json.loads(
                    metrics_path.read_text(encoding="utf-8")
                )

                checkpoint = torch.load(
                    run_dir / "best_model.pt",
                    map_location=device
                )
                model = MLP(
                    checkpoint["hidden_sizes"]
                ).to(device)
                model.load_state_dict(checkpoint["model_state_dict"])

                test_metrics = evaluate(model, test_loader, device)
                metrics.update({
                    f"test_{key}": number
                    for key, number in test_metrics.items()
                })
            else:
                config = {
                    "group": args.group,
                    "value": value,
                    "train_size": train_size,
                    "hidden_sizes": hidden_sizes,
                    "seed": seed,
                    "data_seed": 42,
                    "batch_size": 32,
                    "learning_rate": 0.001,
                    "max_epochs": 1000,
                    "patience": 100,
                    "optimizer": "Adam",
                    "activation": "Tanh",
                    "device": str(device),
                    "torch_version": str(torch.__version__),
                }

                # Lấy các mẫu đầu tiên của train cố định.
                # Các tập A lồng nhau, không lấy mẫu có hoàn lại.
                base_train, _, _ = create_loaders(seed=seed)
                train_pool = base_train.dataset

                if train_size > len(train_pool):
                    raise ValueError("Không đủ mẫu trong train.csv")

                train_loader = DataLoader(
                    Subset(train_pool, range(train_size)),
                    batch_size=32,
                    shuffle=True,
                    generator=torch.Generator().manual_seed(seed)
                )

                print(
                    f"Train {args.group}: value={value}, seed={seed}",
                    flush=True
                )

                metrics = fit(
                    train_loader=train_loader,
                    val_loader=val_loader,
                    hidden_sizes=hidden_sizes,
                    seed=seed,
                    output_dir=run_dir,
                    device=device
                )

                config_path.write_text(
                    json.dumps(config, indent=2),
                    encoding="utf-8"
                )

            metrics_path.write_text(
                json.dumps(metrics, indent=2),
                encoding="utf-8"
            )

            row = {
                **config,
                "hidden_sizes": str(config["hidden_sizes"]),
                **metrics
            }
            results.append(row)

            print(
                f"value={value}, seed={seed}, "
                f"val MSE={metrics['val_mse']:.8f}",
                flush=True
            )

    # Tên riêng cho mỗi danh sách seed và giai đoạn chạy.
    seed_label = "_".join(map(str, args.seeds))
    phase = "test" if args.evaluate_test else "validation"
    summary_path = root / f"summary_{seed_label}_{phase}.csv"

    with summary_path.open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.DictWriter(file, fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)

    print("Đã lưu:", summary_path)


if __name__ == "__main__":
    main()