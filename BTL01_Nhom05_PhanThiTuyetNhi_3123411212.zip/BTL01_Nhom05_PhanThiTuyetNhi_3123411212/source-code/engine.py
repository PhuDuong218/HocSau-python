import csv
import time
from pathlib import Path

import torch
from torch import nn

from model import MLP


def evaluate(model, loader, device):
    model.eval()

    squared_error = 0.0
    absolute_error = 0.0
    count = 0

    with torch.no_grad():
        for X, y in loader:
            X, y = X.to(device), y.to(device)
            predictions = model(X)

            assert predictions.shape == y.shape

            errors = predictions - y
            squared_error += errors.square().sum().item()
            absolute_error += errors.abs().sum().item()
            count += y.size(0)

    mse = squared_error / count

    return {
        "mse": mse,
        "mae": absolute_error / count,
        "rmse": mse ** 0.5,
    }


def fit(
    train_loader,
    val_loader,
    hidden_sizes,
    seed,
    output_dir,
    device,
    learning_rate=0.001,
    max_epochs=1000,
    patience=100,
):
    torch.manual_seed(seed)

    model = MLP(hidden_sizes).to(device)
    optimizer = torch.optim.Adam(
        model.parameters(), lr=learning_rate
    )
    criterion = nn.MSELoss()

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    checkpoint_path = output_dir / "best_model.pt"
    best_val = float("inf")
    best_epoch = 0
    waiting = 0
    history = []

    if device.type == "cuda":
        torch.cuda.synchronize()
    start = time.perf_counter()

    for epoch in range(1, max_epochs + 1):
        model.train()
        error_sum = 0.0
        count = 0

        for X, y in train_loader:
            X, y = X.to(device), y.to(device)

            predictions = model(X)
            assert predictions.shape == y.shape
            loss = criterion(predictions, y)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            error_sum += loss.item() * y.size(0)
            count += y.size(0)

        train_mse = error_sum / count
        val_mse = evaluate(model, val_loader, device)["mse"]

        history.append([epoch, train_mse, val_mse])

        if val_mse < best_val:
            best_val = val_mse
            best_epoch = epoch
            waiting = 0

            torch.save({
                "model_state_dict": model.state_dict(),
                "hidden_sizes": hidden_sizes,
                "input_scale": [2.0, 4.0],
                "seed": seed,
                "epoch": epoch,
                "val_mse": val_mse,
            }, checkpoint_path)
        else:
            waiting += 1

        if waiting >= patience:
            break

    if device.type == "cuda":
        torch.cuda.synchronize()
    seconds = time.perf_counter() - start

    with (output_dir / "training_log.csv").open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.writer(file)
        writer.writerow(["epoch", "train_mse", "val_mse"])
        writer.writerows(history)

    # Đánh giá lại train/validation tại cùng checkpoint tốt nhất.
    checkpoint = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])

    train_metrics = evaluate(model, train_loader, device)
    val_metrics = evaluate(model, val_loader, device)

    return {
        "best_epoch": best_epoch,
        "epochs_run": epoch,
        "training_seconds": seconds,
        "parameters": sum(p.numel() for p in model.parameters()),
        "train_mse": train_metrics["mse"],
        "val_mse": val_metrics["mse"],
        "val_mae": val_metrics["mae"],
        "val_rmse": val_metrics["rmse"],
    }