from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset


def load_dataset(file_path):
    """
    Đọc CSV có ba cột x1, x2, y.

    Trả về:
        X: tensor float32, shape (N, 2)
        y: tensor float32, shape (N, 1)
    """
    data = np.loadtxt(
        file_path,
        delimiter=",",
        skiprows=1,
        ndmin=2
    )

    if data.shape[1] != 3:
        raise ValueError(f"{file_path} phải có ba cột x1, x2, y")

    # Chia theo miền đề bài để cả hai đặc trưng về khoảng [-1, 1].
    X = data[:, :2] / np.array([2.0, 4.0])

    # Giữ nguyên giá trị nhãn Gaussian.
    y = data[:, 2:3]

    X = torch.tensor(X, dtype=torch.float32)
    y = torch.tensor(y, dtype=torch.float32)

    return TensorDataset(X, y)


def create_loaders(data_dir="data", batch_size=32, seed=42):
    data_dir = Path(data_dir)

    train_dataset = load_dataset(data_dir / "train.csv")
    val_dataset = load_dataset(data_dir / "validation.csv")
    test_dataset = load_dataset(data_dir / "test.csv")

    # Cố định thứ tự shuffle của train khi chạy lại.
    generator = torch.Generator().manual_seed(seed)

    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        generator=generator
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False
    )

    return train_loader, val_loader, test_loader


if __name__ == "__main__":
    train_loader, val_loader, test_loader = create_loaders()

    X_batch, y_batch = next(iter(train_loader))

    print("Số mẫu train:", len(train_loader.dataset))
    print("Số mẫu validation:", len(val_loader.dataset))
    print("Số mẫu test:", len(test_loader.dataset))
    print("Shape X batch:", X_batch.shape)
    print("Shape y batch:", y_batch.shape)
    print("Kiểu dữ liệu:", X_batch.dtype, y_batch.dtype)