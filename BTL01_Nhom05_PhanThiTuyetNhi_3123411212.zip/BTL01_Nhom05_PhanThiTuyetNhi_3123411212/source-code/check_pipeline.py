import torch

from dataset import create_loaders
from model import MLP


train_loader, _, _ = create_loaders(batch_size=32)
model = MLP(hidden_sizes=[10])

X_batch, y_batch = next(iter(train_loader))
predictions = model(X_batch)

print("Input:", X_batch.shape)
print("Nhãn:", y_batch.shape)
print("Dự đoán:", predictions.shape)

assert predictions.shape == y_batch.shape

loss = torch.nn.MSELoss()(predictions, y_batch)
print("MSE của mô hình chưa huấn luyện:", loss.item())