def XuLyKhongTrung(a):

    s = set([])

    for ai in a:
        s.add(ai)

    return sorted(s)


a = ['A', 'G', 'C', 'A', 'C', 'F', 'F', 'T', 'H']

b = XuLyKhongTrung(a)

print(b)


def DemSoLanXuatHien(a):

    dem = {}

    for ai in a:
        if dem.get(ai) is None:
            dem[ai] = 1
        else:
            dem[ai] = dem[ai] + 1

    return dem


a = ['A', 'G', 'C', 'A', 'C', 'F', 'F', 'T', 'H']

b = DemSoLanXuatHien(a)

print(b)