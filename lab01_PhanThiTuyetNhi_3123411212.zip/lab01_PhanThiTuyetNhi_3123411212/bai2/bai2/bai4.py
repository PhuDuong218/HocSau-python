s = input("Moi ban nhap chuoi ky so s: ")

en = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]
vi = ["khong", "mot", "hai", "ba", "bon", "nam", "sau", "bay", "tam", "chin"]
num = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

if s.lower() not in en:
    print("Chuoi vua nhap khong hop le!")
else:
    print("Chuoi vua nhap hop le!")
    p = en.index(s.lower())
    print(f'"{s}" bieu dien cho "{num[p]}" va ung voi tieng Viet "{vi[p]}"')

