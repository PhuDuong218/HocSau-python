def NhapMang():

    line = input("Moi ban nhap mang (cach nhau khoang trang): ")
    a = []
    a_snum = line.split(" ")

    for ai in a_snum:
        a.append(ai)

    return a


a = NhapMang()
print(a)


def XuatMang(a):

    print(f'Mang co {len(a)} phan tu: ', end='')

    for i in range(len(a)):
        print(a[i], end=' ')

    print()


a = [1, 4, 1, 2, 3, 4, 1, 2, 3, 3, 1, 2, 3, 4, 10, 2]

XuatMang(a)


import random


def SinhNgauNhien(n, vmin=-10, vmax=10):

    a = []

    for i in range(n):
        ai = random.randint(vmin, vmax)
        a.append(ai)

    return a


b = SinhNgauNhien(30, -10, 10)
print(b)

b = SinhNgauNhien(30, vmin=0)
print(b)

b = SinhNgauNhien(30, vmax=2)
print(b)


def DemTongChanLe(a):

    tong = 0
    sochan = 0
    sole = 0

    for ai in a:
        tong = tong + ai

        if ai % 2 == 0:
            sochan = sochan + 1
        else:
            sole = sole + 1

    return tong, sochan, sole


a = [
    1, 4, 2, 0, -1, -7, 3, -6, 4, 9, -5, 7, 7, -7,
    -10, 1, -10, 9, -4, -6, 10, -2, -10, -8, -3, 2,
    -7, -10, 6, 0
]

print(DemTongChanLe(a))

a = [
    9, 6, 5, 0, 8, 8, 1, 10, 0, 0, 1, 1, 2, 7, 1,
    10, 9, 1, 10, 8, 2, 8, 4, 5, 4, 5, 5, 3, 6, 2
]

print(DemTongChanLe(a))


def DayChanLe(a):
    
    achan = []
    ale = []

    for ai in a:
        if ai % 2 == 0:
            achan.append(ai)
        else:
            ale.append(ai)

    return achan, ale


a = [
    1, 4, 2, 0, -1, -7, 3, -6, 4, 9, -5, 7, 7, -7,
    -10, 1, -10, 9, -4, -6, 10, -2, -10, -8, -3, 2,
    -7, -10, 6, 0
]

achan, ale = DayChanLe(a)

print(f'DayChanLe:\nChan = {achan}\nLe = {ale}\n')