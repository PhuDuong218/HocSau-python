# Xấp xỉ hàm Gaussian hai chiều bằng MLP

Dự án sử dụng mạng MLP trong PyTorch để xấp xỉ mật độ Gaussian hai chiều. Mỗi mẫu gồm hai tọa độ `(x1, x2)` và một nhãn liên tục `y = f(x1, x2)`. Các thực nghiệm khảo sát ảnh hưởng của số mẫu train, số neuron và số tầng ẩn đến sai số dự đoán.

## 1. Cài đặt môi trường

Dự án được chạy với **Python 3.14.7** trên Windows. Các lệnh bên dưới dùng PowerShell tại thư mục gốc dự án. Chỉ cần tạo `.venv` khi thiết lập môi trường mới.

```powershell
py -3.14 --version
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Các thư viện chính là NumPy, Matplotlib và PyTorch. `requirements.txt` ghi lại các phiên bản thư viện đã dùng. Dự án hỗ trợ CPU. Các script huấn luyện dùng CUDA nếu PyTorch nhận diện được GPU tương thích.

## 2. Quy trình chạy

### Sinh và kiểm tra dữ liệu

```powershell
.\.venv\Scripts\python.exe generate_data.py
.\.venv\Scripts\python.exe check_pipeline.py
```

`generate_data.py` sinh ba tập độc lập và lưu CSV với các cột `x1,x2,y`. Script cũng lưu các biểu đồ khảo sát trong `figures/`. `check_pipeline.py` kiểm tra một batch thực tế đi qua MLP. Đầu vào có shape `(B, 2)`, nhãn và dự đoán đều có shape `(B, 1)`.

### Huấn luyện baseline

```powershell
.\.venv\Scripts\python.exe train.py
```

Script lưu checkpoint tốt nhất theo validation MSE, log huấn luyện, đồ thị loss và dự đoán test vào `outputs/baseline/`.

### Chạy thực nghiệm A/B/C

```powershell
.\.venv\Scripts\python.exe experiments.py --group A --seeds 42 43 44
.\.venv\Scripts\python.exe experiments.py --group B --seeds 42 43 44
.\.venv\Scripts\python.exe experiments.py --group C --seeds 42 43 44
```

Ba nhóm có tổng cộng 72 lần huấn luyện. Mỗi lần chạy lưu cấu hình, metrics, log và checkpoint theo nhóm, giá trị khảo sát và seed. Chạy lại cùng cấu hình và seed sẽ ghi kết quả vào cùng đường dẫn.

### Đánh giá test và tổng hợp

Sau khi huấn luyện đủ các cấu hình và chốt lựa chọn theo validation, chạy:

```powershell
.\.venv\Scripts\python.exe experiments.py --group A --seeds 42 43 44 --evaluate-test
.\.venv\Scripts\python.exe experiments.py --group B --seeds 42 43 44 --evaluate-test
.\.venv\Scripts\python.exe experiments.py --group C --seeds 42 43 44 --evaluate-test
.\.venv\Scripts\python.exe summarize_results.py
.\.venv\Scripts\python.exe visualize_model.py
```

`--evaluate-test` dùng checkpoint có sẵn để tính MSE, MAE và RMSE. `summarize_results.py` xuất bảng và biểu đồ trung bình ± độ lệch chuẩn qua ba seeds. `visualize_model.py` chọn cấu hình theo validation MSE trung bình, dùng checkpoint seed 42 để vẽ bề mặt xấp xỉ và xuất `test_predictions.csv` với các cột `x1,x2,y_true,y_pred`.

## 3. Cấu hình thực nghiệm

Tọa độ được lấy mẫu đều với `x1 ∈ [-2, 2]` và `x2 ∈ [-4, 4]`. Nhãn được tính từ hàm mật độ Gaussian với `μ = [0, 0]` và ma trận hiệp phương sai `[[0.3, -0.5], [-0.5, 2.0]]`.

- **Seed sinh dữ liệu** là `42`. Ba tập dùng các luồng ngẫu nhiên riêng, gồm 2.000 mẫu trong pool train, 400 mẫu validation và 100 mẫu test.
- **Seed huấn luyện** là `42`, `43`, `44` cho A/B/C. Các seed thay đổi khởi tạo trọng số và thứ tự shuffle, còn các tập dữ liệu giữ nguyên. Baseline dùng seed `42`.
- **Baseline** là MLP `2 → 10 → 1`, dùng Tanh ở tầng ẩn và đầu ra tuyến tính.
- **Huấn luyện** dùng `MSELoss`, Adam, learning rate `0.001`, batch size `32`, tối đa `1000` epoch. Early stopping có patience `100`, theo dõi validation MSE.
- **Đánh giá** dùng checkpoint có validation MSE thấp nhất của từng lần chạy. Tập test dùng để báo cáo MSE, MAE và RMSE.

| Nhóm | Yếu tố thay đổi | Điều kiện cố định |
|---|---|---|
| A | Số mẫu train từ 200 đến 2.000, bước 200 | Một tầng ẩn có 10 neuron |
| B | Số neuron từ 1 đến 10 | Một tầng ẩn, 2.000 mẫu train |
| C | Số tầng ẩn từ 1 đến 4 | 10 neuron mỗi tầng, 2.000 mẫu train |

Nhóm A lấy `N` mẫu đầu tiên của cùng một pool train, nên các tập con lồng nhau. Các nhóm dùng cùng tập validation và test.

## 4. Cấu trúc dự án

| File hoặc thư mục | Vai trò |
|---|---|
| `generate_data.py` | Tính Gaussian, sinh dữ liệu, kiểm tra và vẽ biểu đồ dữ liệu |
| `dataset.py` | Đọc CSV, chuẩn hóa đầu vào, tạo `TensorDataset` và `DataLoader` |
| `model.py` | Định nghĩa MLP với số tầng và số neuron có thể cấu hình |
| `check_pipeline.py` | Kiểm tra shape của đầu vào, nhãn và dự đoán trên một batch |
| `train.py` | Huấn luyện và đánh giá baseline |
| `engine.py` | Chứa các hàm huấn luyện, đánh giá và lưu checkpoint |
| `experiments.py` | Chạy các nhóm A/B/C và đánh giá test từ checkpoint |
| `summarize_results.py` | Tính trung bình, độ lệch chuẩn và vẽ biểu đồ so sánh |
| `visualize_model.py` | Chọn cấu hình theo validation, vẽ bề mặt và xuất dự đoán |
| `data/` | Chứa `train.csv`, `validation.csv`, `test.csv` |
| `figures/` | Chứa biểu đồ khảo sát dữ liệu và bề mặt Gaussian thật |
| `outputs/baseline/` | Chứa kết quả và checkpoint baseline |
| `outputs/experiments/` | Chứa cấu hình, checkpoint, log và metrics từng lần chạy A/B/C |
| `outputs/analysis/` | Chứa bảng tổng hợp và biểu đồ thực nghiệm |
| `outputs/selected_model/` | Chứa hình so sánh bề mặt và CSV dự đoán của mô hình được chọn |
| `requirements.txt` | Ghi phiên bản thư viện để tái lập môi trường |

## 5. Chuẩn hóa đầu vào và load checkpoint

Mô hình nhận `[x1 / 2, x2 / 4]`, đưa hai tọa độ về `[-1, 1]`. Nhãn `y` giữ nguyên đơn vị gốc. Khi dự đoán một điểm mới, dùng cùng phép chuẩn hóa đã lưu trong checkpoint.

Ví dụ dưới đây load checkpoint baseline trên CPU. Để dùng checkpoint A/B/C, thay `checkpoint_path` bằng đường dẫn đến file `best_model.pt` của lần chạy tương ứng.

```python
import torch

from model import MLP

checkpoint_path = "outputs/baseline/best_model.pt"
checkpoint = torch.load(checkpoint_path, map_location="cpu")

model = MLP(hidden_sizes=checkpoint["hidden_sizes"])
model.load_state_dict(checkpoint["model_state_dict"])
model.eval()

# Một điểm đầu vào chưa chuẩn hóa, shape (1, 2).
x = torch.tensor([[0.5, -1.0]], dtype=torch.float32)
scale = torch.tensor(checkpoint["input_scale"], dtype=torch.float32)

with torch.no_grad():
    prediction = model(x / scale)

print(f"y dự đoán = {prediction.item():.8f}")
```